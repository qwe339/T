AviUtl Project Generator

[同梱ファイル一覧]

・aviutl_generator.py     - メインのソースコードファイル
・compile.bat            - コンパイル用バッチファイル
・aviutl_generator.ico   - アプリケーションアイコン
・README.txt            - コンパイル手順の説明書　←　今見ているファイル

[使用方法]
１．「compile.bat」と「aviutl_generator.py」を同じフォルダに入れる
２．「compile.bat」をダブルクリックして実行

[機能説明]
このバッチファイルは以下の処理を自動で行います：

１．環境チェックと準備
　・Pythonがインストールされているか確認
　・入っていない場合は自動でダウンロード＆インストール

２．必要なライブラリの準備
　・pipの更新
　・PyInstallerのインストール
　・tkinterdnd2のインストール

３．コンパイル実行
　・aviutl_generator.pyをexeファイルに変換
　・必要なライブラリを全て含めた単一のexeファイルを作成

４．後処理
　・生成したexeファイルを同じフォルダに移動
　・不要な一時ファイルを自動削除

[注意事項]
・インターネット接続が必要です
・管理者権限は不要です
・実行中は途中で中断しないでください
・エラーが出た場合はメッセージを確認してください

[生成されるファイル]
・aviutl_generator.exe
　→これが最終的な実行ファイルです

[トラブル対応]
１．「実行できません」と表示される場合
　→再度実行してください

２．ダウンロードがブロックされる場合
　→セキュリティソフトの設定を確認してください

３．コンパイルに失敗する場合
　→一度フォルダを空にして、最初からやり直してください


AviUtl Project Generator
Copyright (c) 2025 郎

MIT License

本ソフトウェアおよび関連文書のファイル（以下「ソフトウェア」）の複製を取得する全ての人に対し、
ソフトウェアを無制限に扱うことを無償で許可します。これには、ソフトウェアの複製を使用、複写、
変更、結合、掲載、頒布、サブライセンス、および/または販売する権利、およびソフトウェアを提供する
相手に同じことを許可する権利も無制限に含まれます。

上記の著作権表示および本許諾表示を、ソフトウェアのすべての複製または重要な部分に記載するものとします。

ソフトウェアは「現状のまま」で、明示であるか暗黙であるかを問わず、何らの保証もなく提供されます。
ここでいう保証とは、商品性、特定の目的への適合性、および権利非侵害についての保証も含みますが、それに限定されるものではありません。
作者または著作権者は、契約行為、不法行為、またはそれ以外であろうと、ソフトウェアに起因または関連し、あるいはソフトウェアの使用またはその他の扱いによって生じる一切の請求、損害、その他の義務について何らの責任も負わないものとします。

[使用ライブラリのライセンス]

1. Python
   - PSF License
   - https://docs.python.org/3/license.html

2. tkinterdnd2
   - BSD 3-Clause License
   - https://github.com/pmgagne/tkinterdnd2

3. PyInstaller
   - GPL License with a special exception which allows to use PyInstaller 
     to build and distribute non-free programs
   - https://github.com/pyinstaller/pyinstaller/blob/develop/COPYING.txt

4. AviUtl Plugin SDK
   - このソフトウェアは AviUtl Plugin SDK を使用しています
   - http://spring-fragrance.mints.ne.jp/aviutl/

[補足]
・本ソフトウェアは個人利用、商用利用を問わず無料で使用できます
・改変、再配布も自由に行えます
・使用の際は自己責任でお願いします
・不具合や問題が発生しても作者は一切の責任を負いません

[謝辞]
本ソフトウェアの開発にあたり、以下のソフトウェアとそのコミュニティに感謝いたします：
- AviUtl
- PSDToolKit
- Python
- その他、使用している全てのオープンソースソフトウェア